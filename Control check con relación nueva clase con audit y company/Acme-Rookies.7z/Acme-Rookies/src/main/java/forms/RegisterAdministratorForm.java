/*
 * AdministratorForm.java
 *
 * Copyright (c) 2019 Group 16 of Design and Testing II, University of Seville
 */

package forms;

public class RegisterAdministratorForm extends RegisterForm {

	////////////////////////////////////////////////////////////////////////////////
	// Fields

	////////////////////////////////////////////////////////////////////////////////
	// Field access methods

}

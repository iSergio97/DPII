
package controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/register/brotherhood")
public class BrotherhoodController extends AbstractController {

	public BrotherhoodController() {
		super();
	}

}

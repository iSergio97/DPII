/*
 * Rookie.java
 *
 * Copyright (c) 2019 Group 16 of Design and Testing II, University of Seville
 */

package domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;

@Entity
@Access(AccessType.PROPERTY)
public class Rookie extends Actor {

	////////////////////////////////////////////////////////////////////////////////
	// Relationships

	////////////////////////////////////////////////////////////////////////////////
	// Relationship access methods

}
